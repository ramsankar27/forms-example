import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'template-driven-form-example',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
  ],
  templateUrl: './template-driven-form-example.component.html',
  styleUrls: ['./template-driven-form-example.component.css'],
})
export class TemplateDrivenFormExampleComponent {
  // This object stores the values entered into the form fields.
  // We bind the form inputs to this object using ngModel.
  model = {
    username: '',
    password: '',
  };

  // `hide` controls whether the password field shows the text or hides it.
  hide = true;

  // Toggle the password visibility when the eye icon is clicked.
  togglePassword() {
    this.hide = !this.hide;
  }

  // This method runs when the user submits the form.
  // We check if the form is valid before using the data.
  onSubmit(form: NgForm) {
    if (form.valid) {
      console.log('Login form submitted:', this.model);
    }
  }
}
