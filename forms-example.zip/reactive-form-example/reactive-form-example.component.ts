import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { Observable, startWith, map } from 'rxjs';

@Component({
  selector: 'reactive-form-example',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatRadioModule,
    MatSelectModule,
    MatAutocompleteModule,
    MatIconModule,
    MatButtonModule,
  ],
  templateUrl: './reactive-form-example.component.html',
  styleUrls: ['./reactive-form-example.component.css'],
})
export class ReactiveFormExampleComponent {
  // This is the main form object. It stores all form field values and validation state.
  registrationForm: FormGroup;

  // Options for the course select field.
  courses = ['Data science', 'Data analytics', 'Excel', 'Python'];

  // Options for the city autocomplete field.
  cityOptions = ['Delhi', 'Mumbai', 'Bangalore', 'Chennai', 'Kolkata', 'Hyderabad', 'Pune'];
  filteredCities$: Observable<string[]>;

  constructor(private fb: FormBuilder) {
    this.registrationForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      age: ['', [Validators.required, Validators.min(10), Validators.max(100)]],
      gender: ['', Validators.required],
      course: ['', Validators.required],
      city: ['', Validators.required],
      hobbies: this.fb.array([this.fb.control('', Validators.required)]),
    });

    this.filteredCities$ = this.registrationForm.controls['city'].valueChanges.pipe(
      startWith(''),
      map((value) => this._filterCities(value || ''))
    );
  }

  // Shortcut to access the FormArray of hobbies.
  get hobbies(): FormArray {
    return (this.registrationForm.controls['hobbies']) as FormArray;
  }

  // Access the hobby controls as an array so the template can loop over them.
  get hobbyControls(): FormControl[] {
    return this.hobbies.controls as FormControl[];
  }

  // Add a new hobby field to the form array.
  addHobby() {
    this.hobbies.push(this.fb.control('', Validators.required));
  }

  // Remove a hobby field by index.
  removeHobby(index: number) {
    if (this.hobbies.length > 1) {
      this.hobbies.removeAt(index);
    }
  }

  // Handle the form submit button.
  onSubmit() {
    if (this.registrationForm.valid) {
      console.log('Student registration data:', this.registrationForm.value);
    } else {
      this.registrationForm.markAllAsTouched();
    }
  }

  private _filterCities(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.cityOptions.filter((option) => option.toLowerCase().includes(filterValue));
  }
}
